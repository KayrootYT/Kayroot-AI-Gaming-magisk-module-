#!/bin/sh
SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=true
LATESTARTSERVICE=true
REPLACE="

"
sleep 2
# Function to display the banner with logo
Display_Banner() {
  ui_print "========================================="
  ui_print "░█░█░█▀█░█░█░█▀▄░█▀█░█▀█░▀█▀"
  ui_print "░█▀▄░█▀█░░█░░█▀▄░█░█░█░█░░█░"
  ui_print "░▀░▀░▀░▀░░▀░░▀░▀░▀▀▀░▀▀▀░░▀░"
  ui_print "========================================="
}

# Call the function to display the banner
Display_Banner
sleep 2
ui_print " • Module info "
sleep 0.5
ui_print " • Name            : Kayroot-Ai gaming"
sleep 0.5
ui_print " • Codename        : beta"
sleep 0.5
ui_print " • Version         : v1.2 perf+ Based on kayroot Ai"
sleep 0.5
ui_print " • Status          : Official Public Release "
sleep 0.5
ui_print " • Dev             : @Kayroot "
sleep 0.5
ui_print " "
ui_print " • Device Information "
sleep 0.5
ui_print " • Device           : $(getprop ro.product.name) "
sleep 0.5
ui_print " • SoC Version      : $(getprop ro.product.board) "
sleep 0.5
ui_print " • Android Version  : $(getprop ro.build.version.release) "
sleep 0.5
ui_print " • SDK              : $(getprop ro.build.version.sdk) "
sleep 0.5
ui_print " • ABI Version      : $(getprop ro.product.cpu.abi) "
sleep 0.5
ui_print " • Hardware         : $(getprop ro.boot.hardware) "
sleep 0.5
ui_print " • Processor        : $(getprop ro.product.board) "
sleep 0.5
ui_print " • Rom              : $(getprop ro.build.display.id) "
sleep 0.5
ui_print " • Fingerprint      : $(getprop ro.vendor.build.fingerprint) "
sleep 0.5
ui_print " • Kernel           : $(uname -r) "
sleep 0.5
ui_print " • Brand            : $(getprop ro.product.system.brand) "
sleep 0.5
ui_print " • Device           : $(getprop ro.product.system.model) "
sleep 0.5
ui_print " • Android Version  : $(getprop ro.system.build.version.release) "
sleep 0.5
ui_print " • SDK Version      : $(getprop ro.build.version.sdk) "
sleep 0.5
ui_print " • Architecture     : $(getprop ro.product.cpu.abi) "

sleep 2
ui_print "- Extracting module files"
unzip -o "$ZIPFILE" 'gamelist.txt' -d "$MODPATH" >&2
mkdir -p "$MODPATH/system/bin"
unzip -o "$ZIPFILE" 'AI' -d "$MODPATH/system/bin" >&2
ui_print "- Detecting installed game"
sleep 2
counter=1
package_list=$(cmd package list packages | cut -f 2 -d ":")
game_list=$(cat "$MODPATH/gamelist.txt")
echo "$game_list" | while IFS= read -r gamelist; do
    line=$(echo "$gamelist" | awk '!/ /')
    if echo "$package_list" | grep -q "$line"; then
        ui_print "  $counter. $line"
        counter=$((counter + 1))
    else
        sed -i "/$line/d" "$MODPATH/gamelist.txt"
    fi
done
ui_print "  If your game is not detected"
ui_print "  Edit gamelist.txt, add, and reinstall"
sleep 2
chmod +x "$MODPATH/system/bin/AI"